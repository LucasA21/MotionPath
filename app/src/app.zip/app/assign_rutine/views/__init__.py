from .list_view import AssignRutineListView
from .detail_view import AssignRutineDetailView
from .create_view import AssignRutineCreateView
from .update_view import AssignRutineUpdateView
from .delete_view import AssignRutineDeleteView