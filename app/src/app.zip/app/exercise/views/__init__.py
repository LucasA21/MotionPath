from .list_view import ExerciseListView
from .detail_view import ExerciseDetailView
from .create_view import ExerciseCreateView
from .update_view import ExerciseUpdateView
from .delete_view import ExerciseDeleteView