from app.exercise.model import Exercise


"""
Por algún motivo místico de este framework si borramos este import deja de funcionar la autenticación de Django.

Decidimos no perder mas horas de nuestras vidas debuggueando esto.
"""