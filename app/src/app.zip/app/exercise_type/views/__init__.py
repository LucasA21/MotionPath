from .list_view import ExerciseTypeListView
from .detail_view import ExerciseTypeDetailView
from .create_view import ExerciseTypeCreateView
from .update_view import ExerciseTypeUpdateView
from .delete_view import ExerciseTypeDeleteView