from django.views.generic import TemplateView

class ConstructionView(TemplateView):
    template_name = 'construction.html'
