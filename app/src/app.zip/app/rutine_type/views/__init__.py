from .list_view import RutineTypeListView
from .detail_view import RutineTypeDetailView
from .create_view import RutineTypeCreateView
from .update_view import RutineTypeUpdateView
from .delete_view import RutineTypeDeleteView