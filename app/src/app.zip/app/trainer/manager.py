from django.db import models

class TrainerManager(models.Manager):
    pass