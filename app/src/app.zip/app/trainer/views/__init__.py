from .list_view import TrainerListView
from .detail_view import TrainerDetailView
from .creates.create_view import TrainerCreateView
from .update_view import TrainerUpdateView
from .delete_view import TrainerDeleteView
from .creates.make_trainer_view import MakeTrainerView