from .list_view import UserListView
from .details.detail_view import UserDetailView
from .details.detail_profile_view import UserDetailProfileView
from .create_view import UserCreateView
from .updates.update_view import UserUpdateView
from .updates.update_profile_view import UserUpdateProfileView
from .delete_view import UserDeleteView
